package com.magicguru.aistrologer.game.manager.util

import com.magicguru.aistrologer.game.manager.ParticleEffectManager

class ParticleEffectUtil {

    val FallingLeaves = ParticleEffectManager.EnumParticleEffect.FallingLeaves.data.effect
    val test = ParticleEffectManager.EnumParticleEffect.test.data.effect

}

