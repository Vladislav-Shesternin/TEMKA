package com.magicguru.aistrologer.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background :Color = Color.valueOf("17283A")

    val blue_06   : Color = Color.valueOf("062F4F")
    val purple_55 : Color = Color.valueOf("553B78")

}